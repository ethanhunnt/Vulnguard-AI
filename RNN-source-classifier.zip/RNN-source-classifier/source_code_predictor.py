import matplotlib.pyplot as plt
import tensorflow as tf
import numpy as np
from scipy.spatial.distance import cdist

# from tf.keras.models import Sequential  # This does not work!
from tensorflow.python.keras.models import Sequential
from tensorflow.python.keras.layers import Dense, GRU, Embedding
from tensorflow.python.keras.optimizers import Adam
from tensorflow.python.keras.preprocessing.text import Tokenizer
from tensorflow.python.keras.preprocessing.sequence import pad_sequences
from tensorflow.python.keras.models import save_model
from tensorflow.python.keras.models import load_model
import csv 
import pandas as pd 
from IPython.display import display, HTML
import h5py
from random import shuffle
import re
import sys 
from collections import OrderedDict

from pickle import dump
from pickle import load

from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils import to_categorical
import library_utils

max_tokens = 500

#Load the data 
x_train_text , slice_labelset = library_utils.load_prediction_dataset()

#Pad and take care of special tokens
x_train_text = library_utils.padding_seq(slice_labelset,x_train_text)
x_train_text = library_utils.special_token_proces(x_train_text)

# load the trained model
model = load_model('keras_source_code_classifier_balanced.h5')

# Summarize the model
model.summary()

# load the tokenizer
tk = load(open('tokenizer_balanced.pkl', 'rb'))

# Testing on new data 

#tk.fit_on_texts(txt)
txt_seq = tk.texts_to_sequences(x_train_text)
txt_seq_pad = pad_sequences(txt_seq, maxlen=max_tokens)

pred = model.predict_classes(txt_seq_pad)
pred1 = model.predict(txt_seq_pad)
#pred.astype(int)
for x in range(0,len(pred)):
	print str(pred[x])
	
for x in range(0,len(pred1)):
	print str(pred1[x])
#print('\n prediction for \n',pred[1])
