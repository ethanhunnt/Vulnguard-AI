import matplotlib.pyplot as plt
import tensorflow as tf
import numpy as np
from scipy.spatial.distance import cdist

# from tf.keras.models import Sequential  # This does not work!
from tensorflow.python.keras.models import Sequential
from tensorflow.python.keras.layers import Dense, GRU, Embedding, LSTM, Bidirectional, Dropout
from tensorflow.python.keras.optimizers import Adam
from tensorflow.python.keras.preprocessing.text import Tokenizer
from tensorflow.python.keras.preprocessing.sequence import pad_sequences
from tensorflow.python.keras.models import save_model
import csv 
import pandas as pd 
from IPython.display import display, HTML
import h5py
from random import shuffle
import re
import sys 
from collections import OrderedDict
from pickle import dump

from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils import to_categorical

max_tokens = 500

#This max function gives the max number of words inside a sentence after splitting by space, which makes more sense
def getMax(data):
    max_tokens = 0 
    for txt in data:
        if max_tokens < len(txt.split()):
            max_tokens = len(txt.split())
    return max_tokens


'''
#My max which gives line length without splitting by space, dont know if this is right thing or not
def getMax(data):
    max_tokens = 0 
    for txt in data:
        if max_tokens < len(txt):
            max_tokens = len(txt)
    return max_tokens
'''

# Loading the training dataset
def load_train_dataset(file = 'tokenized_train_small_v1.txt'):
	labels = []
	text = []
	slice_labels = []
	f = open(file, 'r')		
	lines = f.readlines()
	shuffle(lines)
	for line in lines:
		data = line.split('\t')
		if len(data) == 3:
			labels.append(int(data[2]))
			text.append(data[1].strip())
			slice_labels.append(data[0].strip())
	return slice_labels,text,labels

# Loading the prediction dataset 
#test.c file -- the order of below is 0 1 0 1 0 1 1 (0 1 0 1 0 1)(The ones only work as they are from training data set, in 2000 examples we provided for training only a few were 1 and hence it is not learning vulnerable code snippets well and hence it is not able to recognize the vulnerable ones 
'''
backward	 VAR5, NULL, 0, NULL, 0 ) char *VAR3 = calloc( VAR5, 1 ); if( FUNC1( VAR4, VAR7, VAR3, FUNC2( VAR2, strdup( VAR3 ) ); free( VAR3 );
backward	 ! memcmp ( VAR4->VAR3, "Annodex", 7 ) ) ! memcmp ( VAR4->VAR3, "AnxData", 7 ) ) VAR4->VAR3 += 9; VAR4->VAR3, VAR2->VAR1 );
backward	 VAR2 = VAR1 VAR3[100]; VAR2 = FUNC2(VAR2); VAR3 * FUNC2(VAR3 * VAR2) wmemset(VAR2, L'A', 50-1);
backward	 FUNC1(int VAR36, LPWSTR *VAR31) if (!FUNC2(VAR31[2], L"software-update")) { VAR7 = FUNC4(VAR36 - 3, VAR31 + 3); FUNC4(VAR9 VAR36, LPWSTR *VAR31) if (!FUNC6(VAR36, VAR31, VAR49)) { FUNC6(int VAR36Tmp, LPWSTR *VAR31Tmp, VAR48 VAR5[VAR6]) wcscpy(VAR5, VAR31Tmp[2]); VAR15 VAR8 = FUNC25(VAR36Tmp, VAR31Tmp); if (!FUNC28(VAR31[0], VAR12) || !VAR12) { VAR50 FUNC29(FUNC30(VAR31[0], VAR3, VAR22, if (VAR7 && !FUNC31(VAR31[0], VAR16, VAR39 VAR32 = FUNC32(VAR31[0], NULL, VAR31[0]); if (FUNC33(VAR36, VAR31, VAR49, LPWSTR *VAR31, LPWSTR VAR14 = FUNC34(VAR36, VAR31); VAR33* FUNC34(int VAR36, VAR33 **VAR31); VAR48 VAR20[VAR6 + 1]; wcscpy(VAR20, VAR27); FUNC21(VAR23Temp, VAR31[0], L"updater.tmp")) { VAR34 FUNC21(LPWSTR VAR19,  VAR24 VAR4, if (FUNC21(VAR23, VAR31[0], L"updater.ini") && VAR40 = FUNC22(VAR31[0], VAR14, if (FUNC24(VAR31[1], VAR45) && VAR45) { VAR34 FUNC21(LPWSTR VAR19,  VAR24 VAR4, VAR40 = FUNC22(VAR31[0], VAR14, if (FUNC24(VAR31[1], VAR45) && VAR45) { FUNC24(VAR24 VAR27, VAR34 &VAR45) wcscpy(VAR20, VAR27); FUNC25(int VAR36, LPWSTR *VAR31) return VAR36 == 4 && !FUNC26(VAR31[3], L"-1"); VAR15 VAR41 = (VAR36Tmp >= 4 && FUNC27(VAR31Tmp[3], L"/replace")); if (!FUNC28(VAR31[0], VAR12) || !VAR12) { VAR50 FUNC29(FUNC30(VAR31[0], VAR3, VAR22, if (VAR7 && !FUNC31(VAR31[0], VAR16, VAR39 VAR32 = FUNC32(VAR31[0], NULL, VAR31[0]); if (FUNC33(VAR36, VAR31, VAR49, LPWSTR *VAR31, LPWSTR VAR14 = FUNC34(VAR36, VAR31);
backward	 int * VAR1 = (int *)malloc(10 * sizeof(int)); VAR1[i] = 0; VAR1[VAR4] = 1; FUNC1(VAR1[i]); free(VAR1);
backward	 return '?'; const VAR18 *VAR11, int *VAR21) VAR3 = (const VAR17 *) (VAR11 + 4); VAR12 = (const VAR17 *) (VAR11 + 2 * 4); VAR2 = (const VAR13 *) (VAR11 + 4 * 4); VAR10 = FUNC2((const VAR18 *) (VAR11 + 5 * 4)); VAR6 = (const VAR23 *) (VAR11 + 5 * 4 + 1); VAR9 = VAR6 + strlen(VAR6) + 1; VAR3 = (const VAR17 *) (VAR11 + 4); VAR12 = (const VAR17 *) (VAR11 + 2 * 4); VAR2 = (const VAR13 *) (VAR11 + 4 * 4); VAR10 = FUNC2((const VAR18 *) (VAR11 + 6 * 4)); VAR6 = (const char *) (VAR11 + 6 * 4 + 1); VAR9 = VAR6 + strlen(VAR6) + 1; VAR16 = FUNC7(VAR7, *VAR5, *VAR2 / 1000000, *VAR3, *VAR12, VAR10, VAR6, VAR1); VAR17 VAR26, VAR17 VAR3, VAR17 VAR12, VAR23 VAR10, const VAR23 *VAR6, VAR1[VAR19 - VAR4] = '\0'; VAR10, VAR6, VAR1); const VAR23 *VAR9) VAR23  VAR14[15]; VAR10, VAR6, VAR3, VAR9); r VAR10, VAR3, VAR9, VAR6); r VAR10, VAR6, VAR9); r VAR10, VAR3, VAR12, VAR9); r FUNC6(VAR14, sizeof(VAR14), "%m-%d %H:%M:%S", VAR14, VAR26, VAR10, VAR6, VAR3, VAR9); r FUNC6(VAR14, sizeof(VAR14), "%m-%d %H:%M:%S", VAR14, VAR26, VAR3, VAR12, VAR10, VAR6, VAR9); r FUNC6(VAR14, sizeof(VAR14), "%m-%d %H:%M:%S", VAR14, VAR26, VAR3, VAR12, VAR10, VAR6, VAR9); r return NULL; VAR16 = FUNC7(VAR7, *VAR5, *VAR2 / 1000000, *VAR3, *VAR12, VAR24 = (VAR13)strlen(VAR16); if (!FUNC8(VAR22, VAR16, VAR24, VAR21)) { VAR24 = (VAR13)strlen(VAR16);
backward	 if (fgets(VAR7+VAR4, (int)(100-VAR4), stdin) != NULL) VAR4 = strlen(VAR7); if (VAR4 > 0 && VAR7[VAR4-1] == '\n') VAR7[VAR4-1] = '\0'; VAR7[VAR4] = '\0'; FUNC2(VAR7, VAR7); static void FUNC2(char * VAR7, ...) FUNC3(VAR2, VAR7); FUNC4(VAR1, VAR7, VAR2);
'''
def load_prediction_dataset(file = 'tokenized_predict.txt'):
    with open(file, 'r') as f:
        labels = []
        text = []

        lines = f.readlines()
    #shuffle(lines)
    for line in lines:
        data = line.split('\t')
        if len(data) == 2:
            labels.append((data[0]))
            text.append(data[1].rstrip())
    return text,labels

#Takes care of special tokens and creates space around them so that vocabulary contains mostly correct terms as Keras tokenizer does not allow to provide a vocabulary so to ensure tk.fit_on_texts corectly works we use this trick for now
def special_token_proces(x_train_text):
	special_token_list = ["!","(",")","->","[","]","{","}","++","--","*","/",">>","<<",".","%s","%n","%d","%x","|","&","&&","||","~",";",",","*",">=","<=","\n","\"","\t","\r",":","%p"]
	for tok_len in range(0,len(x_train_text)):
		for sp_tok_len in range(0,len(special_token_list)):
			if special_token_list[sp_tok_len] in x_train_text[tok_len]:
				#print special_token_list[sp_tok_len]
				x_train_text[tok_len] = x_train_text[tok_len].replace(special_token_list[sp_tok_len]," "+special_token_list[sp_tok_len]+" ")
				#print x_train_text[tok_len]

	return x_train_text
	
# Padding as per the paper the sequence to the max token length 
def padding_seq(slice_labelset,x_train_text):
	#This part does padding of sequences according to the paper 
	for length in range(0,len(slice_labelset)):
		temp_seq = ''
		temp_len = 0
		# If slice is backwards function
		if (slice_labelset[length]) == 'backward':

			#when line length is less than max_tokens length prepend with 0 
			if len(x_train_text[length]) < max_tokens:
				temp_len = max_tokens - len(x_train_text[length])
				for i in range(0,temp_len-1):
					temp_seq = temp_seq + '0'
				x_train_text[length] = temp_seq+" "+x_train_text[length] 

			#when line length is greater than max_tokens length then truncate the difference of length from the beginning of line
			elif len(x_train_text[length]) > max_tokens:
				temp_len = len(x_train_text[length]) - max_tokens			
				x_train_text[length] = x_train_text[length][temp_len:]

		# If slice is forward function		
		elif (slice_labelset[length]) == 'forward':

			#when line length is less than max_tokens length postpend with 0 
			if len(x_train_text[length]) < max_tokens:
				temp_len = max_tokens - len(x_train_text[length])
				for i in range(0,temp_len-1):
					temp_seq = temp_seq + '0'
				x_train_text[length] = x_train_text[length]+" "+temp_seq

			#when line length is greater than max_tokens length then truncate the difference of length from the ending of line
			elif len(x_train_text[length]) > max_tokens:
				temp_len = len(x_train_text[length]) - max_tokens			
				x_train_text[length] = x_train_text[length][0:-temp_len]


		# If slice is unknown_slice function, then same as forward for now 		
		elif (slice_labelset[length]) == 'unknown_slice':

			#when line length is less than max_tokens length postpend with 0 
			if len(x_train_text[length]) < max_tokens:
				temp_len = max_tokens - len(x_train_text[length])
				for i in range(0,temp_len):
					temp_seq = temp_seq + '0'
				x_train_text[length] = x_train_text[length] + temp_seq

			#when line length is greater than max_tokens length then truncate the difference of length from the ending of line
			elif len(x_train_text[length]) > max_tokens:
				temp_len = len(x_train_text[length]) - max_tokens			
				x_train_text[length] = x_train_text[length][0:-temp_len]
	return x_train_text
#(max _token 500)
def create_model(num_words): 
	model = Sequential()
	embedding_size = 50#original value 8, but replaced by 10, I think more word embeddings require more number of units in GRU or LSTM as analysis was wrong with high number of embeddedings 
	model.add(Embedding(input_dim=num_words+1,
						output_dim=embedding_size,
						input_length=max_tokens,
						name='layer_embedding'))

	#model.add(GRU(units=16, name = "gru_1",return_sequences=True))
	#model.add(GRU(units=8, name = "gru_2" ,return_sequences=True))
	#model.add(GRU(units=4, name= "gru_3"))
	model.add(Bidirectional(LSTM(100, return_sequences=True)))
	model.add(Bidirectional(LSTM(100)))
	model.add(Dropout(0.5))
	model.add(Dense(50, activation='relu'))
	model.add(Dense(2, activation='softmax',name="dense_1"))
	optimizer = Adam(lr=1e-3)
	model.compile(loss='categorical_crossentropy',
				  optimizer=optimizer,
				  metrics=['accuracy'])
	return model