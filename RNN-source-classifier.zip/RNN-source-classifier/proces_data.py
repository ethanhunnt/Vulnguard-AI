import re 
from util.c_tokenizer import C_Tokenizer
tokenize = C_Tokenizer().tokenize

def process_dataset():
	# declare all the required stuff 
	m = ''
	backward_slice_funcs = ["memcpy","wmemcpy","memccpy","memmove","wmemmove","memset","wmemset","memcmp","wmemcmp","memchr","wmemchr","strncpy","strncpy*","lstrcpyn","tcsncpy*","mbsnbcpy*","wcsncpy*","wcsncpy","strncat","mbsncat","wcsncat","bcopy","strcpy","lstrcpy","wcscpy","tcscpy","mbscpy","CopyMemory","strcat","lstrcat","lstrlen","strchr","strcmp","strcoll","strcspn","strerror","strlen","strpbrk","strrchr","strspn","strstr","strtok","strxfrm","readline","fgets","sscanf","swscanf","sscanf_s","swscanf_s","printf","vprintf","swprintf","vsprintf","asprintf","vasprintf","fprintf","sprintf","snprintf","snwprintf","vsnprintf","CString.Format","CString.FormatV","CString.FormatMessage","CStringT.Format","CStringT.FormatV","CStringT.FormatMessage","CStringT.FormatMessageV","syslog","malloc","Winmain","GetRawInput","GetComboBoxInfo","GetWindowText","GetKeyNameText","Dde","GetFileMUI","GetLocaleInfo","GetString","GetCursor","GetScroll","GetDlgItem","GetMenuItem","free","calloc","strtoul","strtol"]	
	forward_slice_funcs = ["cin","getenv","getenv_s","wgetenv","wgetenv_s","catgets","gets","getchar","getc","getch","getche","kbhit","stdin","getdlgtext","getpass","scanf","fscanf","vscanf","vfscanf","istream.get","istream.getline","istream.peek","istream.read","istream.putback","streambuf.sbumpc","streambuf.sgetc","streambuf.sgetn","streambuf.snextc","streambuf.sputbackc","SendMessage","SendMessageCallback","SendNotifyMessage","PostMessage","PostThreadMessage","recv","recvfrom","Receive","ReceiveFrom","ReceiveFromEx","Socket.Receive","fread","recv","main"]
	text = []
	labels = []
	line_combined = ''
	first_line_identifier = ['cppfunc','cfunc','inputfunc','Buffer_Overflow_cpycat','Buffer_Overflow_Indexes','Buffer_Overflow_LowBound','Buffer_Overflow_scanf','Buffer_Overflow_boundedcpy','Format_String_Attack','String_Termination_Error','Buffer_Overflow_unbounded','Off_by_One_Error_in_Methods','Missing_Precision','Buffer_Overflow_fgets']
	
	#open file and read lines 
	f=open('cwe119_cgd.txt','r')
	lines = f.readlines()
	
	#start processing removing the CVE/CWE first line, then removing ------ line, then combining all the otehr lines of code gadget as 1 line seperated by tab and 1 and 0 of that gadget assigned as label to labels 
	for line in lines:
		m = re.search('[0-9]+\s[0-9]*/*(CVE|CWE)',line.strip())
		if (m is not None or any(x in line.strip() for x in first_line_identifier)):
			#print m#(line.strip()) 
			m = ''
			continue
		elif (line.strip() == "---------------------------------"):
			text.append(line_combined)
			line_combined = ''
			m = ''
		else:
			line_combined = line_combined+" "+line.strip()
			m = ''
	
	for i in range(0,len(text)):
		labels.append(text[i][-1])
		text[i] = text[i][0:len(text[i])-1]
	
	# adding backward or forward function identifier to a code gadget 
	for i in range(0,len(text)):
		if any(x in text[i] for x in backward_slice_funcs):
			text[i] = "backward"+"\t"+text[i]
			#print text[i].strip()
			continue
		elif any(x in text[i] for x in forward_slice_funcs):
			text[i] = "forward"+"\t"+text[i]
			#print text[i].strip()
			continue			
		else:
			text[i] = "unknown_slice"+"\t"+text[i]
			#print text[i].strip()
			continue
	
	#opening new file to write the data set 
	f1 = open('new_dataset.txt','w')
	for i in range(0,len(text)):
		#print labels[i]
		f1.write(str(text[i]).strip()+"\t"+labels[i]+"\n")
		
	f1.close()
	f.close()
		
		
		
process_dataset()