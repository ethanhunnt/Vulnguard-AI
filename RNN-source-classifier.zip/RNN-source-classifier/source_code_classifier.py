import matplotlib.pyplot as plt
import tensorflow as tf
import numpy as np
from scipy.spatial.distance import cdist

# from tf.keras.models import Sequential  # This does not work!
from tensorflow.python.keras.models import Sequential
from tensorflow.python.keras.layers import Dense, GRU, Embedding, LSTM, Bidirectional
from tensorflow.python.keras.optimizers import Adam
from tensorflow.python.keras.preprocessing.text import Tokenizer
from tensorflow.python.keras.preprocessing.sequence import pad_sequences
from tensorflow.python.keras.models import save_model
import csv 
import pandas as pd 
from IPython.display import display, HTML
import h5py
from random import shuffle
import re
import sys 
from collections import OrderedDict
from pickle import dump

from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils import to_categorical
import library_utils

max_tokens = 500#getMax(x_train_text)
print "Max token length: "+str(max_tokens)

#Load the dataset    
slice_labelset, x_train_text , y_train = library_utils.load_train_dataset()

#padding as per the paper 
x_train_text = library_utils.padding_seq(slice_labelset,x_train_text)

#Take care of special tokens in the string
x_train_text = library_utils.special_token_proces(x_train_text)

# Tokenize the dataset and create padded sequences as per requirement for embedding layer
tk = Tokenizer(filters='')
tk.fit_on_texts(x_train_text)
index_list = tk.texts_to_sequences(x_train_text)
x_train_tokens = pad_sequences(index_list, maxlen=max_tokens)
num_words = len(tk.word_index)


print "Length of Vocabulary: "+str(num_words)
'''
for j in range(0,num_words):
	print str(tk.word_index.keys()[j])+"::"+str(tk.word_index.values()[j])
#print (index_list[0])
#print (x_train_tokens[0])
sys.exit(0)
'''

# Creating the model
model = library_utils.create_model(num_words)

# Train the model
model.fit(x_train_tokens, to_categorical(y_train),
          validation_split=0.08, epochs=5, batch_size=32)
		  
#Save the model 
save_model(
    model,
    "keras_source_code_classifier_balanced.h5",
    overwrite=True,
    include_optimizer=True
)

dump(tk, open('tokenizer_balanced.pkl', 'wb'))
model.summary()