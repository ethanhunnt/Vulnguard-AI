from util.c_tokenizer import C_Tokenizer
tokenize = C_Tokenizer().tokenize
import json
import re

def multiwordReplace(text, wordDic):
	"""
	take a text and replace words that match a key in a dictionary with
	the associated value, return the changed text
	"""
	rc = re.compile('|'.join(map(re.escape, wordDic)))
	def translate(match):
		#print match.group(0)
		return wordDic[match.group(0)]
	return rc.sub(translate, text)

def multiwordReplace2(text, wordDic):
	replacements = wordDic
	test = text
	for x in range(0,len(wordDic)):		
		 re.sub(r"\b"+wordDic.keys()[x]+"\b",wordDic.get(wordDic.keys()[x]) ,test)
	return test

def deep_tokenize():
	text = ''
	func_name=[]
	func_name_dict = {}
	var_name_dict = {}
	var_name_1let_dict = {}

	f=open("test.c","r") #test.c train_small.txt train_small_v1.txt
	f1=open("tokenized_predict.txt","w") #tokenized_predict.txt tokenized_train_small.txt tokenized_train_small_v1.txt
	lines =f.readlines()
	for line in lines:
		#text = text+line.strip()+"\n"
		text = line

		# remove forward, backward and unknown_slice for now 
		if "backward" in text:
			text1 = text.replace("backward","")
		elif "forward" in text:
			text1 = text.replace("forward","")
		elif "unknown_slice" in text:
			text1 = text.replace("unknown_slice","")
		else:
			text1 = text


		#tokenize the source code line 
		tokenized_code, name_dict, name_seq = tokenize(text1.strip())
		
		'''
		print (name_dict.keys())
		print name_seq
		#print (tokenized_code)
		'''
		
		# find tokenized user defined-func_names
		m = re.findall("_<id>_[0-9]+@\s_<op>_\(",tokenized_code)
		
		if m is not None:
			for j in range(0,len(m)):
				h = (re.search(r'\d+', m[j]).group())
				func_name.append(name_dict.keys()[name_dict.values().index(h)])

		#create a func_name_dict for replacing userdefned functions with func1,func2, etc
		v = 0
		for v in range(0,len(func_name)):
			func_name_dict.update({func_name[v]: "FUNC"+str(v+1)})

		v = 0
		#create a var_name_dict for replacing userdefned variables with var1,var2, etc
		for v in range(0,len(name_dict)):
			#This is to take care for now where "i" is replaced when i is alone and also when i is in if, switch, etc.
			if len(name_dict.keys()[v]) == 1:
				var_name_1let_dict.update({name_dict.keys()[v]: "VAR"+str(v+1)})
				var_name_dict.update({name_dict.keys()[v]: name_dict.keys()[v]})
			else:
				var_name_dict.update({name_dict.keys()[v]: "VAR"+str(v+1)})
		'''
		print func_name
		print func_name_dict
		print var_name_dict
		print var_name_1let_dict
		'''
		if len(func_name_dict) > 0:
			str2 = multiwordReplace(text, func_name_dict)
		else:
			str2 = text
		
		
		if len(var_name_dict) > 0:
			str3 = multiwordReplace(str2, var_name_dict)
		else:
			str3 = str2
		'''
		# special 1 letter variables and handling them to take care for now where "i" is replaced when i is alone and also when i is in if, switch, etc.
		if len(var_name_1let_dict) > 0:
			x = 0
			for x in range(0,len(var_name_1let_dict)):
			#b = re.findall("[\[,\(,\s]+"+var_name_1let_dict.keys()[0],str3)
			#print b
				str3 = re.sub("[\[]+"+var_name_1let_dict.keys()[x],"["+var_name_1let_dict.get(var_name_1let_dict.keys()[x]) ,str3)
				str3 = re.sub("[\s]+"+var_name_1let_dict.keys()[x]+"[\]]"," "+var_name_1let_dict.get(var_name_1let_dict.keys()[x])+"]",str3)
				
				str3 = re.sub("[\(]+"+var_name_1let_dict.keys()[x],"("+var_name_1let_dict.get(var_name_1let_dict.keys()[x]) ,str3)
				str3 = re.sub("[\s]+"+var_name_1let_dict.keys()[x]+"\)"," "+var_name_1let_dict.get(var_name_1let_dict.keys()[x])+")" ,str3)
				
				str3 = re.sub("[\s]+"+var_name_1let_dict.keys()[x]+"[\s]+"," "+var_name_1let_dict.get(var_name_1let_dict.keys()[x])+" " ,str3)
		'''
		
		#print str3
		f1.write(str3)
		
		#clear all the values  of dictionaries used in 1 iteration
		del func_name[:]
		func_name_dict.clear()
		var_name_dict.clear()
		var_name_1let_dict.clear()
		if type(name_dict) == 'Dict':
			name_dict.clear()
		else:
			name_dict = ''
		if type(name_dict) == 'list':
			del name_seq[:]
		else:
			name_seq = ''
		
		#clear all the values  of strings used in 1 iteration
		text1 = ''
		text = ''
		str2 = ''
		str3 = ''
		tokenized_code = ''
	f.close()	
	f1.close()	
	
deep_tokenize()