linebar = ''
f=open('f.txt','r')
for line in f.readlines():
	linebar = linebar + str(line).strip()
	
f.close()
f=open('f.txt','w')
f.write(str(linebar).strip())
f.close()