import angr
import sys
from collections import *


def call_graph(addr):
	b = angr.Project("test_c",auto_load_libs=False) 
	cfg = b.analyses.CFGFast() 
	#cfg = b.analyses.CFGAccurate(context_sensitivity_level=2,keep_state=True)
	
	#Get cfg_node for the block and then get its function addres, 
	cnode = cfg.get_any_node(addr)
	func_addr = cnode.function_address
	'''
	#so that we can get a block node from address above
	func =  cfg.functions.function(func_addr)
	bnode = func.get_node(addr)
	print bnode
	'''
	#duplicated bnode so that we preserve the value of bnode
	bnode1 = cnode
	
	dic = OrderedDict()

	# Starting predecessor ascent
	pred = bnode1.predecessors
	
		
	#adding node to our dict
	if(len(pred) > 0):
		print "first address ka pred"
		dic.update({(bnode1.addr):pred})
		indice_key = 0
	else:
		print "Some how we got here whihch means no predecesssors"
		sys.exit(0)
		#break

	while indice_key < len(dic):	
		pred = []			
		pred = dic.get(dic.keys()[indice_key])
		print "indice_key: "+str(indice_key)
		
		if len(pred) == 1:
			print "inside single len pred"
			#print pred[0].addr
			# Now taking the value of pred's predecessors and assigning it to bnode1  and also checking if address of indice is greater than the address of its predecessors as we want to go up only and not identify any nodes coming from down i.e. the assumption 
			if (int(dic.keys()[indice_key]) > int(pred[0].addr)):
				dic.update({(pred[0].addr):pred[0].predecessors}) 
			#print dict(dic)
			indice_key = indice_key+1			

		elif len(pred) > 1:
			
			#adding nodes list to our main list
			bnode1_list = pred
		
		
			for x in range(0,len(bnode1_list)):
				print "inside mutliple len pred"
				#checking if address of indice is greater than the address of its predecessors as we want to go up only and not identify any nodes coming from down 
				
				
				if (int(dic.keys()[indice_key]) > int(bnode1_list[x].addr)):
					pred1 = bnode1_list[x].predecessors()
					dic.update({(bnode1_list[x].addr):pred1})
					#print dic
				
			indice_key = indice_key+1
		else:
			print "I think this should end here so we reached beginning of func so we thought"
			indice_key = indice_key+1
			#sys.exit(0)
			
	
	return dic


def call_graph_strcpy():
	b = angr.Project("test_c",auto_load_libs=False) 
	cfg = b.analyses.CFGFast()
	strcpy_cfgnode = ''
	list_strcpy_pred = ''
	strcpy_pred_node = ''
	strcpy_pred_addr = ''
	
	#Go over cfg nodes an find the node with strcpy
	v= [a for a in cfg.nodes() if a.name == 'strcpy'] 
	
	#now go over the list of nodes identified above and extract the first from the list (This is for ease, actually need to extract all of them)
	if len(v) > 0:
		strcpy_cfgnode = v[0]
	
	#Get list of predecessors for strcpy and then get its list pf predecessor since strcpy's pred is 1 and its pred is actual strcpy which has a list of at least 2 address one whhich is strcpy actual itself and one which is above node
	if strcpy_cfgnode != '':
		list_strcpy_pred = strcpy_cfgnode.predecessors[0].predecessors
		print list_strcpy_pred
		
	#Again extract the address of the predecessor for strcpy ..assuming it to be 1 for now, but can be more
	if list_strcpy_pred != '' and len(list_strcpy_pred) > 1:
		# This is assuming the [0] element for strcpy predecssor is always itself and hence it fucks up our logic 		
		strcpy_pred_node = list_strcpy_pred[1]
		
	
	if strcpy_pred_node != '':
		strcpy_pred_addr = strcpy_pred_node.addr
	
	return strcpy_pred_addr,cfg

strcpy_pred_addr1,cfg1 = call_graph_strcpy()
print "strcpy_cfgnode1: "+str(hex(strcpy_pred_addr1))


if strcpy_pred_addr1 != '':
	dic1 = call_graph(strcpy_pred_addr1) #4212200	 4237048
	func_name_list = []
	#print dic1
	for i in range(0, len(dic1)):
		name_addr = cfg1.get_node(dic1.keys()[i]).function_address
		func_name_list.append(cfg1.get_node(name_addr).name)
		value = dic1.get(dic1.keys()[i])
		for j in range(0,len(value)):
			cfg_node = value[j]
			func_name_list.append(cfg1.get_node(cfg_node.function_address).name)
	print func_name_list
else:
	print "Looks like we did not get strcpy predecessor address"

			

		

