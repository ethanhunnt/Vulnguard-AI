void test(char *str);
int main(int argc, char *argv[]);
	
void test(char *str)
{
	int MAXSIZE=40;
	char buf[MAXSIZE];
	if(!buf)
	return;
	strcpy(buf, str); 
}

int main(int argc, char *argv[])
{
	char *userstr;
	if(argc > 1) 
	{
		userstr = argv[1];
		test(userstr);
	}
	return 0;
}